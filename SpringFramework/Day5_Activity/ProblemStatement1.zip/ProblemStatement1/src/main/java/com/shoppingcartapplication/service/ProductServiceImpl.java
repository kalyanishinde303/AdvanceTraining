package com.shoppingcartapplication.service;


import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shoppingcartapplication.Product;
import com.shoppingcartapplication.dao.ProductDAO;


@Service
public abstract class ProductServiceImpl implements ProductService {
	
	private ProductDAO productDAO;

	public void setPersonDAO(ProductDAO productDAO) {
		this.productDAO = productDAO;
	}

	@Override
	@Transactional
	public void addProduct(Product p) {
		this.productDAO.addProduct(p);
	}

	@Override
	@Transactional
	public void updateProduct(Product p) {
		this.productDAO.updateProduct(p);
	}

	@Override
	@Transactional
	public List<Product> listProducts() {
		return this.productDAO.listProducts();
	}

	@Override
	@Transactional
	public Product getProductById(int ProductID) {
		return this.productDAO.getProductById(ProductID);
	}

	@Override
	@Transactional
	public void removeProduct(int ProductID) {
		this.productDAO.removeProduct(ProductID);
	}

}
