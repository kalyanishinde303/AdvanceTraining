package com.shoppingcartapplication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.shoppingcartapplication.Product;
import com.shoppingcartapplication.service.ProductService;

@Controller
public class ProductController {
private ProductService productService;
	
	@Autowired(required=true)
	@Qualifier(value="productService")
	public void setProductService(ProductService ps){
		this.productService = ps;
	}
	
	@RequestMapping(value = "/products", method = RequestMethod.GET)
	public String listProducts(Model model) {
		model.addAttribute("product", new Product());
		model.addAttribute("listProducts", this.productService.listProducts());
		return "product";
	}
	
	//For add and update person both
	@RequestMapping(value= "/product/add", method = RequestMethod.POST)
	public String addPerson(@ModelAttribute("product") Product p){
		
		if(p.getProductID() == 0){
			//new person, add it
			this.productService.addProduct(p);
		}else{
			//existing person, call update
			this.productService.updateProduct(p);
		}
		
		return "redirect:/products";
		
	}
	
	@RequestMapping("/remove/{id}")
    public String removePerson(@PathVariable("ProductID") int ProductID){
		
        this.productService.removeProduct(ProductID);
        return "redirect:/persons";
    }
 
    @RequestMapping("/edit/{ProductID}")
    public String editProduct(@PathVariable("ProductID") int ProductID, Model model){
        model.addAttribute("product", this.productService.getProductById(ProductID));
        model.addAttribute("listProducts", this.productService.listProducts());
        return "person";
    }
}
